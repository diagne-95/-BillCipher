Folder to save the websites source
