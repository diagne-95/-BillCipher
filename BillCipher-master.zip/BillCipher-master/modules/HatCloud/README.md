# HatCloud

HatCloud build in Ruby. It makes bypass in CloudFlare for discover real IP.
This can be useful if you need test your server and website. Testing your protection against Ddos (Denial of Service) or Dos.
CloudFlare is services and distributed domain name server services, sitting between the visitor and the Cloudflare user's hosting provider, acting as a reverse proxy for websites. 
Your network protects, speeds up and improves availability for a website or the mobile application with a DNS change. 

Version: 1.0

<em>Use:</em>
<strong>ruby hatcloud.rb -h or --help </strong><br />
<strong>ruby hatcloud.rb -b your site </strong> <br />
or<br />
<strong>ruby hatcloud.rb --byp your site </strong><br />

# Screenshot
<img src="https://4.bp.blogspot.com/-fdVSt_L_8WM/Wz41jru6M5I/AAAAAAAAM8s/v30nv-t6aYsvDr-LoOMcuBWxfBsY-Uq-QCLcBGAs/s1600/Hat%2BCloud%2B2%2Bmin%2B.png"> <br />HatCloud build in Ruby. It makes bypass in CloudFlare for discover real IP.
This can be useful if you need test your server and website. Testing your protection against Ddos (Denial of Service) or Dos.
CloudFlare is services and distributed domain name server services, sitting between the visitor and the Cloudflare user's hosting provider, acting as a reverse proxy for websites. 
Your network protects, speeds up and improves availability for a website or the mobile application with a DNS change.
